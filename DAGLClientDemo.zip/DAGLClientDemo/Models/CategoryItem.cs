﻿using DAGLClientDemo.Interfaces;
namespace DAGLClientDemo.Models
{
    public class CategoryItem :ICategoryItem
    {
        public CategoryItem() { } 
        public string? Name { get; set; }
        public string? User { get; set; }
        public string? Description { get; set; }
        public ulong Price { get; set; }
        public string? ImageUrl { get; set; }
    }
}
