﻿using DAGLClientDemo.Interfaces;

namespace DAGLClientDemo.Models
{
    public class ClientConfig : IClientConfig
    {
        public ClientConfig( bool hostHttpOnly, string host, int hostHttpPort, int hostHttpsPort,
                               bool daglApiHttpOnly, string daglApiHost, int daglApiHttpPort, int daglApiHttpsPort)
        {
            HostHttpOnly = hostHttpOnly;
            Host = host;
            HostHttpPort = hostHttpPort;
            HostHttpsPort = hostHttpsPort;
            DAGLApiHttpOnly = daglApiHttpOnly;
            DAGLApiHost = daglApiHost;
            DAGLApiHttpPort = daglApiHttpPort;
            DAGLApiHttpsPort = daglApiHttpsPort;

        }
        public bool HostHttpOnly { get; private set; } = default!;
        public string? Host { get; private set; } = default!;
        public int HostHttpPort { get; private set; } = default!;
        public int HostHttpsPort { get; private set; } = default!;
        public bool DAGLApiHttpOnly { get; private set; } = default!;
        public string? DAGLApiHost { get; private set; }
        public int DAGLApiHttpPort { get; private set; }
        public int DAGLApiHttpsPort { get; private set; }
    }
}
