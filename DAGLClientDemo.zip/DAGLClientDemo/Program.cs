using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI;
//using Microsoft.EntityFrameworkCore;
using DAGLClientDemo.Areas.Identity;
//using DAGLClientDemo.Data;
using DAGLClientDemo.CustomIdentity;
using DAGLClientDemo.Interfaces;
using DAGLClientDemo.Models;
using DAGLClientDemo.Services;
using MudBlazor.Services;

var c = new ConfigurationBuilder()
                .SetBasePath(AppContext.BaseDirectory)
                .AddJsonFile(Path.Combine(AppContext.BaseDirectory, "appsettings.json"), optional: false);

IConfigurationRoot HostConfig = c.Build();
var daglApiHttpOnly = Boolean.Parse(HostConfig["DAGLConfig:DAGLApiHttpOnly"]);
var daglApiHttpPort = Int32.Parse(HostConfig["DAGLConfig:DAGLApiHttpPort"]);
var daglApiHttpsPort = Int32.Parse(HostConfig["DAGLConfig:DAGLApiHttpsPort"]);
var daglApiHost = HostConfig["DAGLConfig:DAGLApiHost"];
var daglApiKey = HostConfig["DAGLConfig:APIKey"];
var daglApiHttpUrl = $"http://{daglApiHost}:{daglApiHttpPort}";
var daglApiHttpsUrl = $"https://{daglApiHost}:{daglApiHttpsPort}";
var hostHttpOnly = Boolean.Parse(HostConfig["HostConfig:HostHttpOnly"]);
var host = HostConfig["HostConfig:Host"];
var hostHttpPort = Int32.Parse(HostConfig["HostConfig:HostHttpPort"]);
var hostHttpsPort = Int32.Parse(HostConfig["HostConfig:HostHttpsPort"]);
var hostHttpUrl = $"http://{host}:{hostHttpPort}";
var hostHttpsUrl = $"https://{host}:{hostHttpsPort}";


var clientConfig = new ClientConfig(hostHttpOnly, host, hostHttpPort, hostHttpsPort, daglApiHttpOnly, daglApiHost, daglApiHttpPort, daglApiHttpsPort);
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<IClientConfig>(clientConfig);
builder.Services.AddSingleton<IRegisteredUserList,RegisteredUsersService>();
builder.Services.AddSingleton<ICategoryItemsService, CategoryItemsService>();
builder.Services.AddSingleton<IDAGLService>( new DAGLService(daglApiKey, clientConfig) );
builder.Services.AddSingleton<IIdentityPersistenceProvider>(new IdentityPersistenceProvider(Path.Combine(System.AppContext.BaseDirectory, "STORE")));
builder.Services.AddDefaultIdentity<CustomIdentityUser>(options => options.SignIn.RequireConfirmedAccount = false)
    .AddRoles<IdentityRole>()
    .AddClaimsPrincipalFactory<CustomClaimsPrincipalFactory>();

builder.Services.AddSingleton<IUserStore<CustomIdentityUser>, CustomIdentityStore>();
builder.Services.AddSingleton<IRoleStore<IdentityRole>, CustomIdentityRoleStore>();

builder.Services.AddScoped<AuthenticationStateProvider, RevalidatingIdentityAuthenticationStateProvider<CustomIdentityUser>>(); 
builder.Services.AddAuthorization();
//builder.Services.AddAuthorization(options =>
//{
//    //options.AddPolicy("UserClaims", policy => policy.RequireClaim("UserName"));
//    options.AddPolicy(SelfSovereignIdentityClaimTypes.UnoSysIdentityUserUtcCreateDateTime, policy =>
//    policy.RequireClaim(SelfSovereignIdentityClaimTypes.UnoSysIdentityUserUtcCreateDateTime));
//});
// ********** NEW END ********************
builder.Services.AddMudServices();
builder.Services.AddMudBlazorDialog();


builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();


if (hostHttpOnly)
{
    builder.WebHost.UseUrls($"{hostHttpUrl}");
}
else
{
    builder.WebHost.UseUrls($"{hostHttpUrl};{hostHttpsUrl}");
}
var app = builder.Build();
app.Environment.ContentRootPath = AppContext.BaseDirectory;
app.Environment.WebRootPath = Path.Combine(AppContext.BaseDirectory, "wwwroot");
//Console.WriteLine($"AppRootPath={AppContext.BaseDirectory}");
//Console.WriteLine($"ContentRootPath={app.Environment.ContentRootPath}");
//Console.WriteLine($"WebRootPath={app.Environment.WebRootPath}");
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    //app.UseMigrationsEndPoint();
}
else
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    //app.UseHsts();
}

//app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
app.MapBlazorHub();
app.MapFallbackToPage("/_Host");
//Console.WriteLine($"AppRootPath2={AppContext.BaseDirectory}");
//Console.WriteLine($"ContentRootPath2={app.Environment.ContentRootPath}");
//Console.WriteLine($"WebRootPath2={app.Environment.WebRootPath}");
app.Run();
