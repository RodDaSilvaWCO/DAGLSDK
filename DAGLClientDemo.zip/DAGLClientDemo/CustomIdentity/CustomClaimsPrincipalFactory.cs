﻿namespace DAGLClientDemo.CustomIdentity
{
    using Microsoft.AspNetCore.Identity;
    using Microsoft.Extensions.Options;
    using System;
    using System.Diagnostics;
    using System.Security.Claims;
    using System.Threading.Tasks;

    public class CustomClaimsPrincipalFactory : UserClaimsPrincipalFactory<CustomIdentityUser>
    {
        public CustomClaimsPrincipalFactory(
            UserManager<CustomIdentityUser> userManager,
            IOptions<IdentityOptions> optionsAccessor)
                : base(userManager, optionsAccessor)
        {
        }

        protected override async Task<ClaimsIdentity> GenerateClaimsAsync(CustomIdentityUser user)
        {
            var identity = await base.GenerateClaimsAsync(user);
            ////Debug.Print($"...Inside CustomClaimsPrincipalFactory.GenerateClaimsAsync() - {Environment.StackTrace}");
            //identity.AddClaim(new Claim("ApplicationAccessToken", user.ApplicationAccessToken));
            //identity.AddClaim(new Claim("NodeID", user.NodeID.ToString()));
            return identity;
        }
    }
}
