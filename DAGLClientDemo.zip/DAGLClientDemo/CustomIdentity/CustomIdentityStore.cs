﻿namespace DAGLClientDemo.CustomIdentity
{
    using Microsoft.AspNetCore.Identity;
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Security.Claims;
    using System.Threading;
    using System.Threading.Tasks;
    using DAGLClientDemo.Interfaces;
    

    public class CustomIdentityStore :
                    IUserStore<CustomIdentityUser>,
                    IUserPasswordStore<CustomIdentityUser>,
                    IUserClaimStore<CustomIdentityUser>,
                    IUserLockoutStore<CustomIdentityUser>,
                    IUserEmailStore<CustomIdentityUser>,
                    IUserPhoneNumberStore<CustomIdentityUser>,
                    IUserLoginStore<CustomIdentityUser>,
                    IUserAuthenticatorKeyStore<CustomIdentityUser>,
                    IUserTwoFactorStore<CustomIdentityUser>,
                    IUserTwoFactorRecoveryCodeStore<CustomIdentityUser>,
                    IUserRoleStore<CustomIdentityUser>

    {
        #region Member fields and constants
        private IIdentityPersistenceProvider idPersistenceProvider = null!;
        #endregion

        #region Constructor
        public CustomIdentityStore( IIdentityPersistenceProvider idpersistenceprovider )
        {
            idPersistenceProvider = idpersistenceprovider ?? throw new ArgumentNullException( nameof( idpersistenceprovider ) );
        }

        void IDisposable.Dispose()
        {
            // Required Implementation for IUserStore<CustomIdentityUser> - do not remove
        }
        #endregion


        #region IUserStore and IUserEmailStore Implementations
        public async Task<IdentityResult> CreateAsync(CustomIdentityUser identity,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            IdentityResult result = IdentityResult.Success;
            cancellationToken.ThrowIfCancellationRequested();
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            await idPersistenceProvider.UpsertUserAsync(identity).ConfigureAwait(false);
            return result;
        }

        public async Task<IdentityResult> DeleteAsync(CustomIdentityUser identity,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            IdentityResult result = IdentityResult.Success;
            cancellationToken.ThrowIfCancellationRequested();
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            await idPersistenceProvider.DeleteUserAsync(identity.Id).ConfigureAwait(false);
            return result;
        }

        public async Task<IdentityResult> UpdateAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            IdentityResult result = IdentityResult.Success;
            cancellationToken.ThrowIfCancellationRequested();
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            await idPersistenceProvider.UpsertUserAsync(identity).ConfigureAwait(false);
            return result;
        }

        public async Task<CustomIdentityUser> FindByIdAsync(string identityId,
          CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (identityId == null) throw new ArgumentNullException(nameof(identityId));
            return  await idPersistenceProvider.FindUserByIdAsync(identityId).ConfigureAwait(false);
        }


        public async Task<CustomIdentityUser> FindByNameAsync(string identityName,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (identityName == null) throw new ArgumentNullException(nameof(identityName));
            return await idPersistenceProvider.FindUserByNameAsync(identityName).ConfigureAwait(false);
        }

        public async Task<CustomIdentityUser> FindByEmailAsync(string normalizedEmail, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (normalizedEmail == null) throw new ArgumentNullException(nameof(normalizedEmail));
            return await idPersistenceProvider.FindUserByNameAsync(normalizedEmail).ConfigureAwait(false);
        }
        #endregion 


        #region IUserClaimStore Implementation
        public async Task AddClaimsAsync(CustomIdentityUser identity, IEnumerable<Claim> claims, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            if (claims == null) throw new ArgumentNullException(nameof(claims));
            await idPersistenceProvider.UpsertUserClaimsAsync(identity.Id, (List<Claim>)claims).ConfigureAwait(false);
        }

        public async Task<IList<Claim>> GetClaimsAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            return await idPersistenceProvider.GetUserClaimsAsync(identity.Id).ConfigureAwait(false);
        }

        public async Task RemoveClaimsAsync(CustomIdentityUser identity, IEnumerable<Claim> claims, CancellationToken cancellationToken)
        {
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            if (claims == null) throw new ArgumentNullException(nameof(claims));
            await idPersistenceProvider.DeleteUserClaimsAsync(identity.Id, (List<Claim>)claims).ConfigureAwait(false);
        }

        public async Task ReplaceClaimAsync(CustomIdentityUser identity, Claim claim, Claim newClaim, CancellationToken cancellationToken)
        {
            Debug.Print($"SelfSovereignIdentityStore.ReplaceClaimAsync( Enter )");
            await Task.FromResult<bool>(false);  // avoids a compiler warning
            throw new NotImplementedException();
            //Claim candidateReplaceClaim = null!;
            ////foreach( var cc in identity.Claims )
            //if (Claims.ContainsKey(identity.NormalizedUserName))
            //{
            //    foreach (var cc in Claims[identity.NormalizedUserName])
            //    {
            //        if (claim.Type == cc.Type && claim.Value == cc.Value)
            //        {
            //            candidateReplaceClaim = cc;
            //            break;
            //        }
            //    }

            //    if (candidateReplaceClaim != null)
            //    {
            //        //identity.Claims.Remove(candidateReplaceClaim);
            //        //identity.Claims.Add(newClaim);
            //        Claims[identity.NormalizedUserName].Remove(candidateReplaceClaim);
            //        Claims[identity.NormalizedUserName].Add(newClaim);
            //    }
            //    else
            //    {
            //        // couldn't find claim so just add newClaim
            //        //identity.Claims.Add(newClaim);
            //        Claims[identity.NormalizedUserName].Add(newClaim);
            //    }
            //}
            //else
            //{
            //    List<Claim> newclaims = new List<Claim>();
            //    newclaims.Add(newClaim);
            //    Claims.Add(identity.NormalizedUserName, newclaims);
            //}
        }
        #endregion

        #region IUserRoleStore Implementation
        public async Task AddToRoleAsync(CustomIdentityUser identity, string roleName, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            if (roleName == null) throw new ArgumentNullException(nameof(roleName));
            await idPersistenceProvider.UpsertUserRoleAsync(identity.Id, roleName).ConfigureAwait(false);
        }

        public async Task RemoveFromRoleAsync(CustomIdentityUser identity, string roleName, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            if (roleName == null) throw new ArgumentNullException(nameof(roleName));
            await idPersistenceProvider.DeleteUserRoleAsync(identity.Id, roleName).ConfigureAwait(false);
        }

        public async Task<IList<string>> GetRolesAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            return await idPersistenceProvider.GetUserRolesAsync(identity.Id).ConfigureAwait(false);
        }

        public async Task<bool> IsInRoleAsync(CustomIdentityUser identity, string roleName, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            bool result = false;
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            var roles = await idPersistenceProvider.GetUserRolesAsync(identity.Id).ConfigureAwait(false);
            if (roles != null)
            {
                foreach (var role in roles)
                {
                    if (role == roleName)
                    {
                        result = true;
                        break;
                    }
                }
            }
            return result;
        }
        #endregion


        #region User Property Getters and Setters
        public async Task<int> GetAccessFailedCountAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            var result = await Task.FromResult<int>(identity.AccessFailedCount);
            return result;
        }

        public async Task<bool> GetLockoutEnabledAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            var result = await Task.FromResult(identity.LockoutEnabled);
            return result;
        }


        public async Task<DateTimeOffset?> GetLockoutEndDateAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            var result = await Task.FromResult(identity.LockoutEnd);
            return result;
        }

        public async Task<string> GetNormalizedUserNameAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            var result = await Task.FromResult(identity.NormalizedUserName);
            return result;
        }

        public async Task<string> GetPasswordHashAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            return await Task.FromResult(identity.PasswordHash);
        }

        public async Task<string> GetUserIdAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            return await Task.FromResult(identity.Id.ToString());
        }

        public async Task<string> GetUserNameAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            return await Task.FromResult(identity.UserName);
        }

        public async Task<IList<CustomIdentityUser>> GetUsersForClaimAsync(Claim claim, CancellationToken cancellationToken)
        {
            Debug.Print($"SelfSovereignIdentityStore.GetUsersForClaimAsync( Enter )");
            var result = await Task.FromResult<IList<CustomIdentityUser>>((IList<CustomIdentityUser>)new List<CustomIdentityUser>());
            throw new NotImplementedException();
        }

        public async Task<bool> HasPasswordAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            var result = await Task.FromResult<bool>(!string.IsNullOrEmpty( identity.PasswordHash ));
            return result;
        }

        public async Task<int> IncrementAccessFailedCountAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            identity.AccessFailedCount += 1;
            return await Task.FromResult<int>(identity.AccessFailedCount);
        }

       

        public async Task ResetAccessFailedCountAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            identity.AccessFailedCount = 0;
            await Task.FromResult<object>(null!);
        }

        public async Task SetLockoutEnabledAsync(CustomIdentityUser identity, bool enabled, CancellationToken cancellationToken)
        {
            identity.LockoutEnabled = enabled;
            await Task.FromResult<object>(null!);
        }

        public async Task SetLockoutEndDateAsync(CustomIdentityUser identity, DateTimeOffset? lockoutEnd, CancellationToken cancellationToken)
        {
            identity.LockoutEnd = lockoutEnd;
            await Task.FromResult<object>(null!);
        }

        public async Task SetNormalizedUserNameAsync(CustomIdentityUser identity, string normalizedName, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            if (normalizedName == null) throw new ArgumentNullException(nameof(normalizedName));

            identity.NormalizedUserName = normalizedName;
            await Task.FromResult<object>(null!);
        }

        public async Task SetPasswordHashAsync(CustomIdentityUser identity, string passwordHash, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (identity == null) throw new ArgumentNullException(nameof(identity));
            if (passwordHash == null) throw new ArgumentNullException(nameof(passwordHash));

            identity.PasswordHash = passwordHash;
            await Task.FromResult<object>(null!);

        }

        public async Task SetUserNameAsync(CustomIdentityUser identity, string identityName, CancellationToken cancellationToken)
        {
            identity.UserName = identityName;
            await Task.FromResult<object>(null!);
        }



        public async Task SetEmailAsync(CustomIdentityUser identity, string email, CancellationToken cancellationToken)
        {
            identity.Email = email;
            await Task.FromResult<object>(null!);
        }

        public async Task<string> GetEmailAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            var result = await Task.FromResult<string>(identity.Email);
            return result;
        }

        public async Task<bool> GetEmailConfirmedAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            var result = await Task.FromResult<bool>(identity.EmailConfirmed);
            return result;
        }

        public async Task SetEmailConfirmedAsync(CustomIdentityUser identity, bool confirmed, CancellationToken cancellationToken)
        {
            identity.EmailConfirmed = confirmed;
            await Task.FromResult<object>(null!);
        }

        

        public async Task<string> GetNormalizedEmailAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            var result = await Task.FromResult<string>(identity.NormalizedEmail);
            return result;
        }

        public async Task SetNormalizedEmailAsync(CustomIdentityUser identity, string normalizedEmail, CancellationToken cancellationToken)
        {
            identity.NormalizedEmail = normalizedEmail;
            await Task.FromResult<object>(null!);

        }

        public async Task SetPhoneNumberAsync(CustomIdentityUser identity, string phoneNumber, CancellationToken cancellationToken)
        {
            identity.PhoneNumber = phoneNumber;
            await Task.FromResult<object>(null!);
        }

        public async Task<string> GetPhoneNumberAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            var result = await Task.FromResult<string>(identity.PhoneNumber);
            return result;
        }

        public async Task<bool> GetPhoneNumberConfirmedAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            var result = await Task.FromResult<bool>(identity.PhoneNumberConfirmed);
            return result;
        }

        public async Task SetPhoneNumberConfirmedAsync(CustomIdentityUser identity, bool confirmed, CancellationToken cancellationToken)
        {
            identity.PhoneNumberConfirmed = confirmed;
            await Task.FromResult<object>(null!);
        }

        public async Task AddLoginAsync(CustomIdentityUser identity, UserLoginInfo login, CancellationToken cancellationToken)
        {
            await Task.FromResult<object>(null!);
            throw new NotImplementedException();
        }

        public async Task RemoveLoginAsync(CustomIdentityUser identity, string loginProvider, string providerKey, CancellationToken cancellationToken)
        {
            await Task.FromResult<object>(null!);
            throw new NotImplementedException();
        }

        public async Task<IList<UserLoginInfo>> GetLoginsAsync(CustomIdentityUser user, CancellationToken cancellationToken)
        {
            var result = await Task.FromResult<IList<UserLoginInfo>>( (IList<UserLoginInfo>) new List<UserLoginInfo>() );
            throw new NotImplementedException();
        }

        public async  Task<CustomIdentityUser> FindByLoginAsync(string loginProvider, string providerKey, CancellationToken cancellationToken)
        {
            var result = await Task.FromResult<CustomIdentityUser>(null!);
            throw new NotImplementedException();
        }

        public async Task SetAuthenticatorKeyAsync(CustomIdentityUser identity, string key, CancellationToken cancellationToken)
        {
            await Task.FromResult<object>(null!);
            throw new NotImplementedException();
        }

        public async Task<string> GetAuthenticatorKeyAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            await Task.FromResult<object>(null!);
            throw new NotImplementedException();
        }

        public async Task SetTwoFactorEnabledAsync(CustomIdentityUser identity, bool enabled, CancellationToken cancellationToken)
        {
            identity.TwoFactorEnabled = enabled;
            await Task.FromResult<object>(null!);
        }

        public async Task<bool> GetTwoFactorEnabledAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            var result = await Task.FromResult<bool>(false);
            return result;
        }

        public async Task ReplaceCodesAsync(CustomIdentityUser identity, IEnumerable<string> recoveryCodes, CancellationToken cancellationToken)
        {
            await Task.FromResult<object>(null!);
            throw new NotImplementedException();
        }

        public async Task<bool> RedeemCodeAsync(CustomIdentityUser identity, string code, CancellationToken cancellationToken)
        {
            await Task.FromResult<object>(null!);
            throw new NotImplementedException();
        }

        public async Task<int> CountCodesAsync(CustomIdentityUser identity, CancellationToken cancellationToken)
        {
            var result = await Task.FromResult<int>(0);
            throw new NotImplementedException();
        }

        public Task<IList<CustomIdentityUser>> GetUsersInRoleAsync(string roleName, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
            
        }
        #endregion


        #region Helpers
        private IdentityResult PersistIdentityClaims(CustomIdentityUser identity, IEnumerable<Claim> claims )
        {
            IdentityResult result = IdentityResult.Success;
            //if (string.IsNullOrEmpty(identity.ApplicationAccessToken))
            //{
            //    identity.ApplicationAccessToken = overlayService.GetApplicationAccessTokenAsync().Result;
            //}
            //identity.NodeID = nodeID;
            //var request = new UserClaimsOverlayRequest(identity, claims, reason);
            //var response = overlayService.ProcessUserClaimsOverlayRequestAsync(request).Result;
            //if (response != null)
            //{
            //    if (response.Status == OverlayStatusCode.SUCCESS)
            //    {
            //        var responseObj = HostUtilities.JsonDeserialize<SelfSovereignIdentityRequest>(response.Content);  // Response content is original SelfSovereignIdentityRequest passed in
            //        if (responseObj == null)
            //        {
            //            var error = new IdentityError();
            //            error.Code = "ERROR";
            //            error.Description = "Unexpected null response";
            //            result = IdentityResult.Failed(error);
            //        }
            //    }
            //    else
            //    {
            //        var error = new IdentityError();
            //        error.Code = response.Status.ToString();
            //        error.Description = "PersistIdentityClaims call failed";
            //        result = IdentityResult.Failed(error);
            //    }
            //}
            //else
            //{
            //    throw new InvalidOperationException();
            //}
            return result;
        }

        private IList<Claim> FindUserClaims(CustomIdentityUser identity, string callername)
        {
            IList<Claim> result = new List<Claim>();

            //if (string.IsNullOrEmpty(identity.ApplicationAccessToken))
            //{
            //    identity.ApplicationAccessToken = overlayService.GetApplicationAccessTokenAsync().Result;
            //}
            //identity.NodeID = nodeID;
            //var request = new UserClaimsOverlayRequest(identity, 2 /*OverlayReasonType.READ*/);
            //var response = overlayService.ProcessUserClaimsOverlayRequestAsync(request).Result;
            //if (response != null)
            //{
            //    if (response.Status == OverlayStatusCode.SUCCESS)
            //    {
            //        var responseObj = HostUtilities.JsonDeserialize<SelfSovereignIdentityRequest>(response.Content);
            //        if (responseObj != null)
            //        {
            //            result = responseObj.Claims;
            //        }
            //    }
            //}
            //else
            //{
            //    throw new InvalidOperationException();
            //}
            return result;
        }
 
        #endregion
    }
}
