﻿

namespace DAGLClientDemo.CustomIdentity
{
    using Microsoft.AspNetCore.Identity;

    public class CustomIdentityUser : IdentityUser
    {
        public CustomIdentityUser() : base()
        {
        }
    }


    //public class IgnorePropertyForReflection : Attribute
    //{
    //}

    //public static class TypeExtensions
    //{
    //    public static PropertyInfo[] GetFilteredProperties(this Type type)
    //    {
    //        return type.GetProperties().Where(pi => !pi.IsDefined(typeof(IgnorePropertyForReflection))).ToArray();
    //    }
    //}

}
