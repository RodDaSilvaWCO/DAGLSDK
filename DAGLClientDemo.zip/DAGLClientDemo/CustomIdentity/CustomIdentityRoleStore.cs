﻿namespace DAGLClientDemo.CustomIdentity
{
    using Microsoft.AspNetCore.Identity;
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Threading;
    using System.Threading.Tasks;

    public class CustomIdentityRoleStore : IRoleStore<IdentityRole>
    {
        private Dictionary<string, IdentityRole> _ssirById = new Dictionary<string, IdentityRole>();
        private Dictionary<string, IdentityRole> _ssirByName = new Dictionary<string, IdentityRole>();

        public CustomIdentityRoleStore()
        {
            // Initialize with a couple of roles
            _ssirById.Add("REGISTEREDUSER", new IdentityRole("REGISTEREDUSER"));
            _ssirById.Add("ADMINISTRATOR", new IdentityRole("ADMINISTRATOR"));
        }
        public async Task<IdentityResult> CreateAsync(IdentityRole role, CancellationToken cancellationToken)
        {
            Debug.Print($"CustomIdentityRoleStore.CreateAsync( Enter )");
            IdentityResult result = IdentityResult.Success;
            cancellationToken.ThrowIfCancellationRequested();
            if (role == null) throw new ArgumentNullException(nameof(role));

            if (!_ssirById.ContainsKey(role.Id.ToUpper()))
            {
                _ssirById.Add(role.Id.ToUpper(), role);
                _ssirByName.Add(role.NormalizedName, role);
            }
            else
            {
                var ie = new IdentityError();
                ie.Description = "Role Already Exists";
                result = IdentityResult.Failed(ie);
            }
            Debug.Print($"CustomIdentityRoleStore.CreateAsync( Leave )");
            return await Task.FromResult<IdentityResult>(result);
        }

        public async Task<IdentityResult> DeleteAsync(IdentityRole role, CancellationToken cancellationToken)
        {
            Debug.Print($"CustomIdentityRoleStore.DeleteAsync( Enter )");
            IdentityResult result = IdentityResult.Success;
            cancellationToken.ThrowIfCancellationRequested();
            if (role == null) throw new ArgumentNullException(nameof(role));
            if (_ssirById.ContainsKey(role.Id.ToUpper()))
            {
                _ssirById.Remove(role.Id.ToUpper());
                _ssirByName.Remove(role.NormalizedName);
            }
            else
            {
                var ie = new IdentityError();
                ie.Description = "Role Not Found";
                result = IdentityResult.Failed(ie);
            }
            Debug.Print($"CustomIdentityRoleStore.DeleteAsync( Leave )");
            return await Task.FromResult<IdentityResult>(result);
        }

        public async Task<IdentityResult> UpdateAsync(IdentityRole role, CancellationToken cancellationToken)
        {
            Debug.Print($"CustomIdentityRoleStore.UpdateAsync( Enter )");
            IdentityResult result = IdentityResult.Success;
            cancellationToken.ThrowIfCancellationRequested();
            if (role == null) throw new ArgumentNullException(nameof(role));
            if (_ssirById.ContainsKey(role.Id.ToUpper()))
            {
                _ssirById[role.Id.ToUpper()] = role;
                _ssirByName[role.NormalizedName] = role;
            }
            else
            {
                var ie = new IdentityError();
                ie.Description = "Role Not Found";
                result = IdentityResult.Failed(ie);
            }
            Debug.Print($"CustomIdentityRoleStore.UpdateAsync( Leave )");
            return await Task.FromResult<IdentityResult>(result);
        }

        public void Dispose()
        {
        }

        public async Task<IdentityRole> FindByIdAsync(string roleId, CancellationToken cancellationToken)
        {
            Debug.Print($"CustomIdentityRoleStore.FindByIdAsync( Enter )");
            IdentityRole role = null!;
            cancellationToken.ThrowIfCancellationRequested();
            if (roleId == null) throw new ArgumentNullException(nameof(roleId));
            
            if (_ssirById.ContainsKey(roleId.ToUpper()))
            {
                role = _ssirById[roleId.ToUpper()];
            }
            Debug.Print($"CustomIdentityRoleStore.FindByIdAsync( Leave )");
            return await Task.FromResult<IdentityRole>(role);
        }

        public async Task<IdentityRole> FindByNameAsync(string normalizedRoleName, CancellationToken cancellationToken)
        {
            Debug.Print($"CustomIdentityRoleStore.FindByNameAsync( Enter )");
            IdentityRole role = null!;
            cancellationToken.ThrowIfCancellationRequested();
            if (normalizedRoleName == null) throw new ArgumentNullException(nameof(normalizedRoleName));

            if (_ssirByName.ContainsKey(normalizedRoleName.ToUpper()))
            {
                role = _ssirByName[normalizedRoleName.ToUpper()];
            }
            Debug.Print($"CustomIdentityRoleStore.FindByNameAsync( Leave )");
            return await Task.FromResult<IdentityRole>(role);
        }

        public async Task<string> GetNormalizedRoleNameAsync(IdentityRole role, CancellationToken cancellationToken)
        {
            Debug.Print($"CustomIdentityRoleStore.GetNormalizedRoleNameAsync( Enter )");
            var result = await Task.FromResult<string>(role.NormalizedName);
            Debug.Print($"CustomIdentityRoleStore.GetNormalizedRoleNameAsync( Leave )");
            return result;
        }

        public async Task<string> GetRoleIdAsync(IdentityRole role, CancellationToken cancellationToken)
        {
            Debug.Print($"CustomIdentityRoleStore.GetRoleIdAsync( Enter )");
            var result = await Task.FromResult<string>(role.Id);
            Debug.Print($"CustomIdentityRoleStore.GetRoleIdAsync( Leave )");
            return result;
        }

        public async Task<string> GetRoleNameAsync(IdentityRole role, CancellationToken cancellationToken)
        {
            Debug.Print($"CustomIdentityRoleStore.GetRoleNameAsync( Enter )");
            var result = await Task.FromResult<string>(role.Name);
            Debug.Print($"CustomIdentityRoleStore.GetRoleNameAsync( Leave )");
            return result;
        }

        public async Task SetNormalizedRoleNameAsync(IdentityRole role, string normalizedName, CancellationToken cancellationToken)
        {
            Debug.Print($"CustomIdentityRoleStore.SetNormalizedRoleNameAsync( Enter )");
            role.NormalizedName = normalizedName;
            await Task.FromResult<object>(null!);
            Debug.Print($"CustomIdentityRoleStore.SetNormalizedRoleNameAsync( Leave )");
        }

        public async Task SetRoleNameAsync(IdentityRole role, string roleName, CancellationToken cancellationToken)
        {
            Debug.Print($"CustomIdentityRoleStore.SetRoleNameAsync( Enter )");
            role.Name = roleName;
            await Task.FromResult<object>(null!);
            Debug.Print($"CustomIdentityRoleStore.SetRoleNameAsync( Leave )");
        }
    }
}
