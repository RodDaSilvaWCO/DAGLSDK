﻿using DAGLClientDemo.CustomIdentity;

namespace DAGLClientDemo.Interfaces
{
    public interface IRegisteredUserList
    {
        List<string>? GetUserIdList();
    }
}
