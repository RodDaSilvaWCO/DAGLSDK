namespace DAGLClientDemo.Interfaces
{
    using DAGLClientDemo.CustomIdentity;
    using Microsoft.AspNetCore.Identity;
    using System.Security.Claims;

    public interface IIdentityPersistenceProvider
    {
        Task UpsertUserAsync( CustomIdentityUser user );
        Task<CustomIdentityUser> FindUserByIdAsync(string? userId);
        Task<CustomIdentityUser> FindUserByNameAsync(string? userId);
        Task<CustomIdentityUser> FindUserByEmailAsync(string? userId);
        Task<bool> DeleteUserAsync( string? userId );

        Task UpsertUserRoleAsync(string? userid, string rolename);
        Task<List<string>> GetUserRolesAsync(string? userId);
        Task DeleteUserRoleAsync(string? userId, string? roleName );

        Task UpsertUserClaimsAsync(string userid, List<Claim> claims);
        Task<List<Claim>> GetUserClaimsAsync(string userid);
        Task DeleteUserClaimsAsync(string? userId, List<Claim> claims);

        Task<Dictionary<string, CustomIdentityUser>> LoadRegisteredUsersAsync();
    }
}