﻿using DAGLSdk.Interfaces;
namespace DAGLClientDemo.Interfaces
{
    public interface IDAGLService
    {
        string HostUrl { get; }
        string DAGLApiUrl { get; }
        int HostPort { get; }
        int DAGLApiPort { get; }

        Task<string?> DAGLOperatorPayerDltIdentifier();

        

        Task<string?> DAGLDescription();
        Task<bool> IsRunningAsync();

        Task<bool> IsInitializedAsync();

        Task<string?> GetAccessTokenAsync();

        Task<bool> CreateMemberGeneralLedgerAsync(string memberid);

        Task<long> GetMemberWalletBalanceAsync(string stakeholderid);

        Task<long> GetOperatorWalletBalanceAsync();


        Task<long> GetOperatorPayerDltBalanceAsync();

        Task<ulong> NetMemberPurchaseAmountAsync(ulong grossAmount);

        Task<ulong> NetMemberCashOutAmountAsync(ulong grossAmount);

        Task<ulong> NetOperatorCashOutAmountAsync(ulong grossAmount);

        Task<bool> SynchronousMemberPurchaseAsync(string buyerMemberId, string sellerMemberId, ulong amount);

        Task<string> GetMemberChartOfAccountsAsync(string stakeholderid);

        Task<string> GetOperatorChartOfAccountsAsync();


        Task<string> GetMemberTrialBalanceAsync(string memberid);

        Task<string> GetOperatorTrialBalanceAsync();

        Task<string> GetMemberIncomeStatementAsync(string memberid);

        Task<string> GetOperatorIncomeStatementAsync();

        Task<string> GetMemberBalanceSheetAsync(string memberid);

        Task<string> GetOperatorBalanceSheetAsync();

        Task<string> GetMemberJournalEntriesAsync(string memberid);

        Task<string> GetOperatorJournalEntriesAsync();

        Task<string> GetAuditorJournalEntriesAsync();

        Task<bool> CashOutMemberWalletAsync(string memberId, string dltCryptoAddress, ulong amount);

        Task<bool> CashOutOperatorWalletAsync( string dltCryptoAddress, ulong amount);

    }
}
