﻿namespace DAGLClientDemo.Interfaces
{
    public interface IClientConfig
    {
        bool HostHttpOnly { get; }
        string? Host { get;  }
        int HostHttpPort { get;  }
        int HostHttpsPort { get; }
        bool DAGLApiHttpOnly { get; }
        string? DAGLApiHost { get; }
        int DAGLApiHttpPort { get;  }
        int DAGLApiHttpsPort { get; }
    }
}
