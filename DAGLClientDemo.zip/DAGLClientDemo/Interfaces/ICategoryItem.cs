﻿namespace DAGLClientDemo.Interfaces
{
    public interface ICategoryItem
    {
        string? Name { get; set;  }
        string? User { get; set; }
        string? Description { get; set; }    
        ulong Price { get; set; }
        string? ImageUrl { get; set; }
    }
}
