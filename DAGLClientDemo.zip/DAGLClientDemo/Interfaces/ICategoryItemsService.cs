﻿using DAGLClientDemo.Models;

namespace DAGLClientDemo.Interfaces
{
    public interface ICategoryItemsService
    {
        Task<CategoryItem[]> GetItemsAsync(string categoryFileName );
    }
}
