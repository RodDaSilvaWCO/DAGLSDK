﻿using DAGLClientDemo.Interfaces;
using System.Security.Authentication;
using System.Text.Json;
using DAGLSdk.Interfaces;
using DAGLSdk.Models;
using System.Text;

namespace DAGLClientDemo.Services
{
    public class DAGLService : IDAGLService, IDisposable
    {
        #region Field Members
        private const string DAGL_API_REQUEST_CONTENT_TYPE = "application/json";
       // private const string DAGL_API_REPORTS_CONTROLLER = "api/dGLReports";
        private const string DAGL_API_CONTROLLER = "api/DAGL";
        private HttpClient httpClient = null!;
        private string daglApiUrl = null!;
        private int daglApiPort = 0;
        private string hostUrl = null!;
        private int hostPort = 0;
        private HttpClientHandler clientHandler = null!;
        private string daglApiKey = null!;
        private string? daglAccessToken = null!;
        //private IClientConfig clientConfig = null!;
        #endregion

        #region Constructors
        public DAGLService( string daglapikey, IClientConfig clientConfig )
        {
            clientHandler = GetHandler();
            httpClient = new HttpClient(clientHandler);
            //clientConfig = clientconfig;
            daglApiKey = daglapikey;
            daglApiUrl = $"{(clientConfig!.DAGLApiHttpOnly! ? "http" : "https")}://{clientConfig?.DAGLApiHost!}:{(clientConfig!.DAGLApiHttpOnly! ? clientConfig!.DAGLApiHttpPort : clientConfig!.DAGLApiHttpsPort!)}";
            httpClient.BaseAddress = new Uri(daglApiUrl);
        }
        #endregion

        #region Public Interface
        public void Dispose()
        {
            httpClient?.Dispose();
            httpClient = null!;
            clientHandler?.Dispose();
            clientHandler = null!;
        }


        public string HostUrl { get { return hostUrl; } }

        public string DAGLApiUrl { get { return daglApiUrl;  } }

        public int HostPort { get { return hostPort;  } }
        public int DAGLApiPort { get { return daglApiPort;  } }

        public async Task<string?> DAGLDescription()
        { 
            string? daglname = null!;
            try
            {
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/DAGLDescription/{{0}}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var json = response.Content.ReadAsStringAsync().Result;
                    if (!string.IsNullOrEmpty(json))
                    {
                        daglname = JsonSerializer.Deserialize<string>(json);
                    }
                }
            }
            catch (Exception)
            {
                // NOP - ignore;
            }
            return daglname;
        }

        public async Task<string?> DAGLOperatorPayerDltIdentifier()
        {
            string? dltId = null!;
            try
            {
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/DAGLOperatorPayerDltIdentifier/{{0}}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var json = response.Content.ReadAsStringAsync().Result;
                    if (!string.IsNullOrEmpty(json))
                    {
                        dltId = JsonSerializer.Deserialize<string>(json);
                    }
                }
            }
            catch (Exception)
            {
                // NOP - ignore;
            }
            return dltId;
        }

        public async Task<bool> IsRunningAsync()
        {
            try
            {
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/Ping").ConfigureAwait(false);
                return (response.StatusCode == System.Net.HttpStatusCode.OK);
            }
            catch (Exception)
            {
                return false;
            }
        }

        public async Task<bool> IsInitializedAsync()
        {
            try
            {
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/IsInitialized").ConfigureAwait(false);
                return (response.StatusCode == System.Net.HttpStatusCode.OK);
            }
            catch (Exception)
            {
                return false;
            }
        }

        public async Task<string?> GetAccessTokenAsync()
        {
            var response = await GetAsync($"{DAGL_API_CONTROLLER}/token/{daglApiKey}").ConfigureAwait(false);
            switch(response.StatusCode)
            {
                case System.Net.HttpStatusCode.OK:
                    var accessTokenJson = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    var accessToken = JsonSerializer.Deserialize<string>(accessTokenJson);
                    return accessToken;
                    //return await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                case System.Net.HttpStatusCode.Unauthorized:
                     throw new AuthenticationException("daglapikey could not be authenticated.");
                case System.Net.HttpStatusCode.BadRequest:
                     throw new ArgumentException("daglapikey invalid.");
                default:
                     throw new InvalidOperationException("Unknown issue calling DAGL GetToken.");
            }
        }

        public async Task<ulong> NetMemberPurchaseAmountAsync( ulong grossAmount)
        {
            ulong netAmount = 0UL;
            try
            {
               var response = await GetAsync($"{DAGL_API_CONTROLLER}/NetMemberPurchaseAmount/{{0}}/{grossAmount}", mustAuthenticate:true).ConfigureAwait(false);
               if(response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    netAmount = JsonSerializer.Deserialize<ulong>(json);
                }
               else
                {
                    throw new InvalidOperationException($"NetMemberPruchaseAmount() call failed with status {response.StatusCode}");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return netAmount;
        }


        public async Task<ulong> NetMemberCashOutAmountAsync(ulong grossAmount)
        {
            ulong netAmount = 0UL;
            try
            {
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/NetMemberCashOutAmount/{{0}}/{grossAmount}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    netAmount = JsonSerializer.Deserialize<ulong>(json);
                }
                else
                {
                    throw new InvalidOperationException($"NetMemberCashOutAmount() call failed with status {response.StatusCode}");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return netAmount;
        }

        public async Task<ulong> NetOperatorCashOutAmountAsync(ulong grossAmount)
        {
            ulong netAmount = 0UL;
            try
            {
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/NetOperatorCashOutAmount/{{0}}/{grossAmount}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    netAmount = JsonSerializer.Deserialize<ulong>(json);
                }
                else
                {
                    throw new InvalidOperationException($"NetOperatorCashOutAmount() call failed with status {response.StatusCode}");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return netAmount;
        }

        public async Task<bool> CreateMemberGeneralLedgerAsync( string memberid )
        {
            bool result = false;
            try
            {
                #region Validate arguements
                if (string.IsNullOrEmpty(memberid))
                {
                    throw new ArgumentException(nameof(memberid));
                }
                #endregion
                var response = await PostAsync($"{DAGL_API_CONTROLLER}/CreateMemberGL/{{0}}/{memberid}").ConfigureAwait(false);
                result = (response.StatusCode == System.Net.HttpStatusCode.Accepted);
            }
            catch (Exception )
            {
                result = false;
            }
            return result;
        }

        public async Task<long> GetMemberWalletBalanceAsync(string stakeholderid)
        {
            long walletBalance = 0;
            try
            {
                #region Validate arguements
                if (string.IsNullOrEmpty(stakeholderid))
                {
                    throw new ArgumentException(nameof(stakeholderid));
                }
                #endregion
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/MemberWalletBalance/{{0}}/{stakeholderid}", mustAuthenticate:true).ConfigureAwait(false);
                if(response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    walletBalance = JsonSerializer.Deserialize<long>(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
                }
                else
                {
                    throw new InvalidOperationException("Unable to retrieve Wallet balance at this time.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return walletBalance;
        }


        public async Task<long> GetOperatorWalletBalanceAsync()
        {
            long walletBalance = 0;
            try
            {
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/OperatorWalletBalance/{{0}}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    walletBalance = JsonSerializer.Deserialize<long>(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
                }
                else
                {
                    throw new InvalidOperationException("Unable to retrieve Wallet balance at this time.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return walletBalance;
        }


        public async Task<long> GetOperatorPayerDltBalanceAsync()
        {
            long dltBalance = 0;
            try
            {
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/OperatorPayerDltBalance/{{0}}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    dltBalance = JsonSerializer.Deserialize<long>(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
                }
                else
                {
                    throw new InvalidOperationException("Unable to retrieve Operator Payer balance at this time.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return dltBalance;
        }


        public async Task<bool> SynchronousMemberPurchaseAsync( string buyerMemberId, string sellerMemberId, ulong amount )
        {
            bool result = false;
            try
            {
                #region Validate arguements
                if (string.IsNullOrEmpty(buyerMemberId))
                {
                    throw new ArgumentException(nameof(buyerMemberId));
                }
                if (string.IsNullOrEmpty(sellerMemberId))
                {
                    throw new ArgumentException(nameof(sellerMemberId));
                }
                if (amount == 0)
                {
                    throw new ArgumentException(nameof(amount));
                }
                #endregion
                if (daglAccessToken == null)
                {
                    var jsonToken = await GetAccessTokenAsync().ConfigureAwait(false);
                    if (!string.IsNullOrEmpty(jsonToken))
                    {
                        daglAccessToken = JsonSerializer.Deserialize<string>(jsonToken);
                    }
                    else
                    {
                        throw new InvalidOperationException("Unknown issue calling DAGL GetToken.");
                    }
                }
                SynchronousMemberPurchaseRequest request = new SynchronousMemberPurchaseRequest
                {
                    AccessToken = daglAccessToken,
                    BuyerMemberID = buyerMemberId,
                    SellerMemberID = sellerMemberId,
                    Amount = amount
                };
                var content = new StringContent(JsonSerializer.Serialize(request), Encoding.UTF8, "application/json");
                var response = await PostAsync($"{DAGL_API_CONTROLLER}/SynchronousMemberPurchase", content).ConfigureAwait(false);
                result = (response.StatusCode == System.Net.HttpStatusCode.Accepted);
            }
            catch (Exception)
            {
                result = false;
            }
            return result;
        }


        public async Task<bool> CashOutMemberWalletAsync(string memberId, string dltCryptoAddress, ulong amount)
        {
            bool result = false;
            try
            {
                #region Validate arguements
                if (string.IsNullOrEmpty(memberId))
                {
                    throw new ArgumentException(nameof(memberId));
                }
                if (string.IsNullOrEmpty(dltCryptoAddress))
                {
                    throw new ArgumentException(nameof(dltCryptoAddress));
                }
                if (amount == 0)
                {
                    throw new ArgumentException(nameof(amount));
                }
                #endregion
                if (daglAccessToken == null)
                {
                    var jsonToken = await GetAccessTokenAsync().ConfigureAwait(false);
                    if (!string.IsNullOrEmpty(jsonToken))
                    {
                        daglAccessToken = JsonSerializer.Deserialize<string>(jsonToken);
                    }
                    else
                    {
                        throw new InvalidOperationException("Unknown issue calling DAGL GetToken.");
                    }
                }
                GLApiCryptoTransferRequest request = new GLApiCryptoTransferRequest
                {
                    AccessToken = daglAccessToken,
                    MemberID = memberId,
                    DltCryptoAddress = dltCryptoAddress,
                    Amount = amount
                };
                var content = new StringContent(JsonSerializer.Serialize(request), Encoding.UTF8, "application/json");
                var response = await PostAsync($"{DAGL_API_CONTROLLER}/CashOutMemberWallet", content).ConfigureAwait(false);
                result = (response.StatusCode == System.Net.HttpStatusCode.Accepted);
            }
            catch (Exception)
            {
                result = false;
            }
            return result;
        }



        public async Task<bool> CashOutOperatorWalletAsync(string dltCryptoAddress, ulong amount)
        {
            bool result = false;
            try
            {
                #region Validate arguements
                if (string.IsNullOrEmpty(dltCryptoAddress))
                {
                    throw new ArgumentException(nameof(dltCryptoAddress));
                }
                if (amount == 0)
                {
                    throw new ArgumentException(nameof(amount));
                }
                #endregion
                if (daglAccessToken == null)
                {
                    var jsonToken = await GetAccessTokenAsync().ConfigureAwait(false);
                    if (!string.IsNullOrEmpty(jsonToken))
                    {
                        daglAccessToken = JsonSerializer.Deserialize<string>(jsonToken);
                    }
                    else
                    {
                        throw new InvalidOperationException("Unknown issue calling DAGL GetToken.");
                    }
                }
                GLApiCryptoTransferRequest request = new GLApiCryptoTransferRequest
                {
                    AccessToken = daglAccessToken,
                    DltCryptoAddress = dltCryptoAddress,
                    Amount = amount
                };
                var content = new StringContent(JsonSerializer.Serialize(request), Encoding.UTF8, "application/json");
                var response = await PostAsync($"{DAGL_API_CONTROLLER}/CashOutOperatorWallet", content).ConfigureAwait(false);
                result = (response.StatusCode == System.Net.HttpStatusCode.Accepted);
            }
            catch (Exception)
            {
                result = false;
            }
            return result;
        }


        public async Task<string> GetMemberTrialBalanceAsync(string memberid)
        {
            string trialBalance = null!;
            try
            {
                #region Validate arguements
                if (string.IsNullOrEmpty(memberid))
                {
                    throw new ArgumentException(nameof(memberid));
                }
                #endregion
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/MemberTrialBalance/{{0}}/{memberid}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    trialBalance = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                }
                else
                {
                    throw new InvalidOperationException("Unable to retrieve Trial Balance at this time.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return trialBalance;
        }

        public async Task<string> GetOperatorTrialBalanceAsync()
        {
            string trialBalance = null!;
            try
            {
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/OperatorTrialBalance/{{0}}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    trialBalance = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                }
                else
                {
                    throw new InvalidOperationException("Unable to retrieve Trial Balance at this time.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return trialBalance;
        }




        public async Task<string> GetMemberChartOfAccountsAsync(string memberid)
        {
            string coa = null!; 
            try
            {
                #region Validate arguements
                if (string.IsNullOrEmpty(memberid))
                {
                    throw new ArgumentException(nameof(memberid));
                }
                #endregion
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/MemberChartOfAccounts/{{0}}/{memberid}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    coa = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                }
                else
                {
                    throw new InvalidOperationException("Unable to retrieve Chart of Accounts at this time.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return coa;
        }

        public async Task<string> GetOperatorChartOfAccountsAsync()
        {
            string coa = null!;
            try
            {
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/OperatorChartOfAccounts/{{0}}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    coa = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                }
                else
                {
                    throw new InvalidOperationException("Unable to retrieve Chart of Accounts at this time.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return coa;
        }

        public async Task<string> GetMemberIncomeStatementAsync(string memberid)
        {
            string trialBalance = null!;
            try
            {
                #region Validate arguements
                if (string.IsNullOrEmpty(memberid))
                {
                    throw new ArgumentException(nameof(memberid));
                }
                #endregion
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/MemberIncomeStatement/{{0}}/{memberid}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    trialBalance = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                }
                else
                {
                    throw new InvalidOperationException("Unable to retrieve Income Statement at this time.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return trialBalance;
        }

        public async Task<string> GetOperatorIncomeStatementAsync()
        {
            string trialBalance = null!;
            try
            {
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/OperatorIncomeStatement/{{0}}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    trialBalance = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                }
                else
                {
                    throw new InvalidOperationException("Unable to retrieve Income Statement at this time.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return trialBalance;
        }


        public async Task<string> GetMemberBalanceSheetAsync(string memberid)
        {
            string trialBalance = null!;
            try
            {
                #region Validate arguements
                if (string.IsNullOrEmpty(memberid))
                {
                    throw new ArgumentException(nameof(memberid));
                }
                #endregion
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/MemberBalanceSheet/{{0}}/{memberid}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    trialBalance = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                }
                else
                {
                    throw new InvalidOperationException("Unable to retrieve BalanceSheet at this time.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return trialBalance;
        }

        public async Task<string> GetOperatorBalanceSheetAsync()
        {
            string trialBalance = null!;
            try
            {
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/OperatorBalanceSheet/{{0}}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    trialBalance = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                }
                else
                {
                    throw new InvalidOperationException("Unable to retrieve BalanceSheet at this time.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return trialBalance;
        }

        public async Task<string> GetMemberJournalEntriesAsync(string memberid )
        {
            string journalEntries = null!;
            try
            {
                #region Validate arguements
                if (string.IsNullOrEmpty(memberid))
                {
                    throw new ArgumentException(nameof(memberid));
                }
                #endregion
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/MemberJournalEntries/{{0}}/{memberid}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    journalEntries = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                }
                else
                {
                    throw new InvalidOperationException("Unable to retrieve Journal Entries at this time.");
                }
            }
            catch (Exception)
            {
                journalEntries = "Unable to retrieve Journal Entries at this time.  Please try again.";
            }
            return journalEntries;
        }

        public async Task<string> GetOperatorJournalEntriesAsync( )
        {
            string journalEntries = null!;
            try
            {
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/OperatorJournalEntries/{{0}}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    journalEntries = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                }
                else
                {
                    throw new InvalidOperationException("Unable to retrieve Journal Entries at this time.");
                }
            }
            catch (Exception)
            {
                journalEntries = "Unable to retrieve jJournal Entries at this time.  Please try again.";
            }
            return journalEntries;
        }

        public async Task<string> GetAuditorJournalEntriesAsync()
        {
            string journalEntries = null!;
            try
            {
                var response = await GetAsync($"{DAGL_API_CONTROLLER}/AuditorJournalEntries/{{0}}", mustAuthenticate: true).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    journalEntries = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                }
                else
                {
                    throw new InvalidOperationException("Unable to retrieve Journal Entriess at this time.");
                }
            }
            catch (Exception)
            {
                journalEntries = "Unable to retrieve Journal Entries at this time.  Please try again.";
            }
            return journalEntries;
        }
        #endregion

        #region Helpers
        private async Task<HttpResponseMessage> PostAsync( string url, HttpContent content = null!)
        {
            if (daglAccessToken == null)
            {
                var accessToken = await GetAccessTokenAsync().ConfigureAwait(false);
                if (!string.IsNullOrEmpty(accessToken))
                {
                    daglAccessToken = accessToken; // JsonSerializer.Deserialize<string>(jsonToken);
                }
                else
                {
                    throw new InvalidOperationException("Unknown issue calling DAGL GetToken.");
                }
            }
            HttpResponseMessage response = null!;
            while (true)
            {
                response = await httpClient.PostAsync(string.Format(url,daglAccessToken), content).ConfigureAwait(false);
                if (response.StatusCode == System.Net.HttpStatusCode.OK || response.StatusCode == System.Net.HttpStatusCode.Accepted)
                {
                    break;
                }
                else
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        // If we make it here we likely need to refresh the acess token, so fetch a new one and loop around and try the Api call again
                        var accessToken = await GetAccessTokenAsync().ConfigureAwait(false);
                        if (!string.IsNullOrEmpty(accessToken))
                        {
                            daglAccessToken = accessToken; // JsonSerializer.Deserialize<string>(jsonToken);
                        }
                        else
                        {
                            throw new InvalidOperationException("Unknown issue calling DAGL GetToken.");
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
            return response;
        }

        private async Task<HttpResponseMessage> GetAsync(string url, bool mustAuthenticate = false )
        {
            if (!mustAuthenticate)
            {
                return await httpClient.GetAsync(url).ConfigureAwait(false);
            }
            else
            {
                if (daglAccessToken == null)
                {
                    var accesstoken = await GetAccessTokenAsync().ConfigureAwait(false);
                    if (!string.IsNullOrEmpty(accesstoken))
                    {
                        daglAccessToken = accesstoken; // JsonSerializer.Deserialize<string>(accesstoken);
                    }
                    else
                    {
                        throw new InvalidOperationException("Unknown issue calling DAGL GetToken.");
                    }
                }
                HttpResponseMessage response = null!;
                while (true)
                {
                    response = await httpClient.GetAsync(string.Format(url, daglAccessToken)).ConfigureAwait(false);
                    if (response.StatusCode == System.Net.HttpStatusCode.OK || response.StatusCode == System.Net.HttpStatusCode.Accepted)
                    {
                        break;
                    }
                    else
                    {
                        if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                        {
                            // If we make it here we likely need to refresh the acess token, so fetch a new one and loop around and try the Api call again
                            var accessToken = await GetAccessTokenAsync().ConfigureAwait(false);
                            if (!string.IsNullOrEmpty(accessToken))
                            {
                                daglAccessToken = accessToken; // JsonSerializer.Deserialize<string>(accessToken);
                            }
                            else
                            {
                                throw new InvalidOperationException("Unknown issue calling DAGL GetToken.");
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                return response;
            }
        }

        private static HttpClientHandler GetHandler()
        {
            var handler = new HttpClientHandler();
            handler.ClientCertificateOptions = ClientCertificateOption.Manual;
            handler.SslProtocols = SslProtocols.None;
            handler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true;  // Accept the DAGL Api HTTPS cert - %TODO% - Should verify the cert for PROD usage
            return handler;
        }
        #endregion
    }
}
