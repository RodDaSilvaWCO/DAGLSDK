﻿using DAGLClientDemo.CustomIdentity;
using DAGLClientDemo.Interfaces;
namespace DAGLClientDemo.Services
{
    public class RegisteredUsersService : IRegisteredUserList
    {
        private IIdentityPersistenceProvider identityPersistenceProvider = null!;
        public List<string>? GetUserIdList()
        { 
            List<string> userIdList = new List<string>();
            try
            {
                var userList = identityPersistenceProvider.LoadRegisteredUsersAsync().Result;
                foreach (var user in userList)
                {
                    if (user.Value.NormalizedUserName != "ADMIN@DAEX.COM")  // do not return Admin account
                    {
                        userIdList.Add(user.Value.UserName);
                    }
                }
            }
            catch (Exception)
            {
                // NOP - ignore
            }
            return userIdList;
        } 

        public RegisteredUsersService(IIdentityPersistenceProvider identitypersistenceprovider )
        {
            identityPersistenceProvider = identitypersistenceprovider;            
        }

    }
}
