namespace DAGLClientDemo.Services
{
    using Microsoft.AspNetCore.Identity;
    using DAGLClientDemo.Interfaces;
    using DAGLClientDemo.CustomIdentity;
    using DAGLClientDemo.Utilities;
    using System.Security.Claims;
    using System.Text.Json;

    public class IdentityPersistenceProvider : IIdentityPersistenceProvider
    {
        #region Field Members
        private const string USERS_FILE = "USERS";
        private const string USER_ROLES_FILE = "USERROLES";
        private const string USER_CLAIMS_FILE = "CLAIMS";
        private const string DAT_EXTENSION = ".DAT";
        private string storeDir = null!;
        private AsyncReaderWriterLock? concurrencyLock = null!;
        #endregion

        #region Constructors
        public IdentityPersistenceProvider(string? storePath)
        {
            if (!Directory.Exists(storePath))
            {
                Directory.CreateDirectory(storePath!);
            }
            storeDir = storePath!;
            concurrencyLock = new AsyncReaderWriterLock();
        }
        #endregion

        #region Public Interface
        #region User APIs
        public async Task UpsertUserAsync(CustomIdentityUser user)
        {
            using (var releaser = await concurrencyLock!.WriterLockAsync().ConfigureAwait(false))
            {
                // Load the users
                var users = await LoadUsersAsync().ConfigureAwait(false);
                if (users.ContainsKey(user.Id))
                {
                    // Already exists - so overwrite
                    users[user.Id] = user;
                }
                else
                {
                    users.Add(user.Id, user);
                }
                // Persist the users 
                await PersistUsersAsync(users).ConfigureAwait(false);
            }
        }


        public async Task<CustomIdentityUser> FindUserByIdAsync(string? userId)
        {
            CustomIdentityUser user = null!;
            if (userId != null)
            {
                using (var releaser = await concurrencyLock!.WriterLockAsync().ConfigureAwait(false))
                {
                    // Load the users
                    var users = await LoadUsersAsync().ConfigureAwait(false);
                    if (users.ContainsKey(userId))
                    {
                        // Already exists - so overwrite
                        user = users[userId];
                    }
                }
            }
            return user;
        }

        public async Task<CustomIdentityUser> FindUserByNameAsync(string? userName)
        {
            CustomIdentityUser user = null!;
            using (var releaser = await concurrencyLock!.WriterLockAsync().ConfigureAwait(false))
            {
                // Load the users
                var users = await LoadUsersAsync().ConfigureAwait(false);
                foreach(var kvp in users)
                {
                    if( kvp.Value.NormalizedUserName ==  userName )
                    {
                        user = kvp.Value;
                        break;
                    }
                }
            }
            return user;
        }

        public async Task<CustomIdentityUser> FindUserByEmailAsync(string? userEmail)
        {
            CustomIdentityUser user = null!;
            using (var releaser = await concurrencyLock!.WriterLockAsync().ConfigureAwait(false))
            {
                // Load the users
                var users = await LoadUsersAsync().ConfigureAwait(false);
                foreach (var kvp in users)
                {
                    if (kvp.Value.NormalizedEmail == userEmail)
                    {
                        user = kvp.Value;
                        break;
                    }
                }
            }
            return user;
        }

        public async Task<bool> DeleteUserAsync( string? userId )
        {
            bool result = false;
            if (userId != null)
            {
                using (var releaser = await concurrencyLock!.WriterLockAsync().ConfigureAwait(false))
                {
                    // Load the users
                    var users = await LoadUsersAsync().ConfigureAwait(false);
                    // Remove the user if it exists
                    if (users[userId] != null)
                    {
                        users.Remove(userId);
                        // Persist the users updated file
                        await PersistUsersAsync(users).ConfigureAwait(false);
                    }
                    else
                    {
                        throw new InvalidOperationException("User not found.");
                    }
                }
            }
            return result;
        }

        public async Task<Dictionary<string,CustomIdentityUser>> LoadRegisteredUsersAsync()
        {
            return await LoadUsersAsync().ConfigureAwait(false);
        }
        #endregion

        #region Role APIs
        public async Task UpsertUserRoleAsync(string? userid, string rolename)
        {
            if( userid == null!)
            {
                throw new ArgumentNullException(nameof(userid));
            }
            if(rolename == null! )
            {
                throw new ArgumentException(nameof(rolename));
            }
            using (var releaser = await concurrencyLock!.WriterLockAsync().ConfigureAwait(false))
            {
                // Load the users roles
                var userRoles = await LoadUserRolesAsync().ConfigureAwait(false);

                // Loop to find role (or add if not exist)
                string foundRole = null!;
                foreach( var r in userRoles.Roles!)
                {
                    if(  r == rolename )
                    {
                        foundRole = r;
                        break;
                    }
                }
                if( foundRole == null )
                {
                    // New Role - adding 
                    foundRole = rolename;
                    userRoles.Roles.Add(foundRole);
                }
                // Loop to find user
                if (userRoles.UserRoles!.ContainsKey(userid))
                {
                    bool doesUserHaveRoleAlready = false;
                    // Loop to see if role is already associated with the user
                    foreach( var r in  userRoles.UserRoles[userid] )
                    {
                        if(r == foundRole)
                        {
                            doesUserHaveRoleAlready = true;
                            break;
                        }
                    }
                    if( !doesUserHaveRoleAlready)
                    {
                        userRoles.UserRoles[userid].Add(rolename);
                    }
                }
                else
                {
                    // User not found so just add it
                    userRoles.UserRoles.Add(userid, new List<string> { foundRole });
                }
                // Persist the user roles
                await PersistUserRolesAsync(userRoles).ConfigureAwait(false);
            }
        }
    

        public async Task<List<string>> GetUserRolesAsync(string? userid)
        {
            List<string> roles = new List<string>();
            if (userid == null!)
            {
                throw new ArgumentNullException(nameof(userid));
            }
            using (var releaser = await concurrencyLock!.WriterLockAsync().ConfigureAwait(false))
            {
                // Load the users roles
                var userRoles = await LoadUserRolesAsync().ConfigureAwait(false);

                // Find user
                if (userRoles.UserRoles!.ContainsKey(userid))
                {
                    roles = userRoles.UserRoles![userid];
                }
            }
            return roles;
        }

        public async Task DeleteUserRoleAsync(string? userid, string? rolename)
        {
            if (userid == null!)
            {
                throw new ArgumentNullException(nameof(userid));
            }
            if (rolename == null!)
            {
                throw new ArgumentException(nameof(rolename));
            }
            bool doesUserHaveRoleAlready = false;
            using (var releaser = await concurrencyLock!.WriterLockAsync().ConfigureAwait(false))
            {
                // Load the users roles
                var userRoles = await LoadUserRolesAsync().ConfigureAwait(false);
                // Loop to find user
                if (userRoles.UserRoles!.ContainsKey(userid))
                {
                    // Loop to see if role is already associated with the user
                    foreach (var r in userRoles.UserRoles[userid])
                    {
                        if (r == rolename)
                        {
                            doesUserHaveRoleAlready = true;
                            break;
                        }
                    }
                    if (doesUserHaveRoleAlready)
                    {
                        userRoles.UserRoles[userid].Remove(rolename);
                    }
                    // If the user has no more roles then remove it altogether
                    if( userRoles.UserRoles[userid].Count == 0)
                    {
                        userRoles.UserRoles.Remove(userid);
                    }
                }
                else
                {
                    throw new InvalidOperationException("User not found.");
                }
                if (doesUserHaveRoleAlready)
                {
                    // Persist the user roles
                    await PersistUserRolesAsync(userRoles).ConfigureAwait(false);
                }

            }
        }
        #endregion

        #region UserClaims APIs
        public async Task UpsertUserClaimsAsync(string userid, List<Claim> claims)
        {
            if (userid == null!)
            {
                throw new ArgumentNullException(nameof(userid));
            }
            if (claims == null!)
            {
                throw new ArgumentException(nameof(claims));
            }
            using (var releaser = await concurrencyLock!.WriterLockAsync().ConfigureAwait(false))
            {
                // Load the users claims
                var userClaims = await LoadUserClaimsAsync().ConfigureAwait(false);

                // Find user
                if (userClaims.UserClaims!.ContainsKey(userid))
                {
                    var userClaimSet = userClaims.UserClaims![userid];
                    // User found so upsert claims
                    foreach ( var c in claims)
                    {
                        int foundClaimPos = 0;
                        foreach( var uc in userClaimSet )
                        {
                            if( c.Type == uc.Type )
                            {
                                break;
                            }
                            foundClaimPos++;
                        }
                        if( foundClaimPos < userClaimSet.Count)
                        {
                            // Replace existing claim
                            userClaimSet[foundClaimPos] = c;
                        }
                        else
                        {
                            // Add new claim to set
                            userClaimSet.Add(c);
                        }
                    }
                }
                else
                {
                    // user not there so just add
                    userClaims.UserClaims.Add( userid, claims );
                }
                // Persist the user claims
                await PersistUserClaimsAsync(userClaims).ConfigureAwait(false);
            }
        }

        public async Task<List<Claim>> GetUserClaimsAsync(string userid)
        {
            List<Claim> claims = new List<Claim>();
            if (userid == null!)
            {
                throw new ArgumentNullException(nameof(userid));
            }
            using (var releaser = await concurrencyLock!.WriterLockAsync().ConfigureAwait(false))
            {
                // Load the users claims
                var userClaims = await LoadUserClaimsAsync().ConfigureAwait(false);

                // Find user
                if (userClaims.UserClaims!.ContainsKey(userid))
                {
                    claims = userClaims.UserClaims![userid];
                }
            }
            return claims;
        }

        public async Task DeleteUserClaimsAsync(string? userid, List<Claim> claims)
        {
            if (userid == null!)
            {
                throw new ArgumentNullException(nameof(userid));
            }
            if (claims == null!)
            {
                throw new ArgumentException(nameof(claims));
            }
            using (var releaser = await concurrencyLock!.WriterLockAsync().ConfigureAwait(false))
            {
                // Load the users claims
                var userClaims = await LoadUserClaimsAsync().ConfigureAwait(false);

                // Find user
                if (userClaims.UserClaims!.ContainsKey(userid))
                {
                    var userClaimSet = userClaims.UserClaims![userid];
                    // User found so delete matching claims
                    foreach (var c in claims)
                    {
                        Claim claimToRemove = null!;
                        foreach (var uc in userClaimSet)
                        {
                            if (c.Type == uc.Type)
                            {
                                claimToRemove = uc;
                                break;
                            }
                        }
                        if (claimToRemove != null)
                        {
                            // Remove existing claim
                            userClaimSet.Remove(claimToRemove);
                        }
                    }
                }
                else
                {
                    throw new InvalidOperationException("User not found.");
                }
                // Persist the user claims
                await PersistUserClaimsAsync(userClaims).ConfigureAwait(false);
            }
        }
        #endregion
        #endregion 


        #region Helpers
        private async Task<Dictionary<string, CustomIdentityUser>> LoadUsersAsync()
        {
            Dictionary<string, CustomIdentityUser>? users = new Dictionary<string, CustomIdentityUser>();
            try
            {
                var userListJson = await File.ReadAllTextAsync(Path.Combine(storeDir, USERS_FILE + DAT_EXTENSION)).ConfigureAwait(false);
                users = JsonSerializer.Deserialize<Dictionary<string, CustomIdentityUser>>(userListJson);
                if( users == null)
                {
                    users = new Dictionary<string, CustomIdentityUser>();
                }
            }
            catch (Exception)
            {
                // No file so create an empty collection
                users = new Dictionary<string, CustomIdentityUser>();
            }
            return users;
        }

        private async Task PersistUsersAsync(Dictionary<string,CustomIdentityUser> users)
        {
            await File.WriteAllTextAsync(Path.Combine(storeDir, USERS_FILE + DAT_EXTENSION), JsonSerializer.Serialize(users)).ConfigureAwait(false);
        }

        private async Task<CustomIdentityUserRoles> LoadUserRolesAsync()
        {
            CustomIdentityUserRoles? userRoles = new CustomIdentityUserRoles();
            try
            {
                var userRolesJson = await File.ReadAllTextAsync(Path.Combine(storeDir, USER_ROLES_FILE + DAT_EXTENSION)).ConfigureAwait(false);
                userRoles = JsonSerializer.Deserialize<CustomIdentityUserRoles>(userRolesJson);
                if (userRoles == null)
                {
                    userRoles = new CustomIdentityUserRoles();
                }
            }
            catch (Exception)
            {
                // No file so create an empty user roles object
                userRoles = new CustomIdentityUserRoles();
            }
            return userRoles;
        }

        private async Task PersistUserRolesAsync(CustomIdentityUserRoles userRoles)
        {
            await File.WriteAllTextAsync(Path.Combine(storeDir, USER_ROLES_FILE + DAT_EXTENSION), JsonSerializer.Serialize(userRoles)).ConfigureAwait(false);
        }

        private async Task<CustomIdentityUserClaims> LoadUserClaimsAsync()
        {
            CustomIdentityUserClaims? userRoles = new CustomIdentityUserClaims();
            try
            {
                var userClaimsJson = await File.ReadAllTextAsync(Path.Combine(storeDir, USER_CLAIMS_FILE + DAT_EXTENSION)).ConfigureAwait(false);
                userRoles = JsonSerializer.Deserialize<CustomIdentityUserClaims>(userClaimsJson);
                if (userRoles == null)
                {
                    userRoles = new CustomIdentityUserClaims();
                }
            }
            catch (Exception)
            {
                // No file so create an empty user roles object
                userRoles = new CustomIdentityUserClaims();
            }
            return userRoles;
        }

        private async Task PersistUserClaimsAsync(CustomIdentityUserClaims userClaims)
        {
            await File.WriteAllTextAsync(Path.Combine(storeDir, USER_CLAIMS_FILE + DAT_EXTENSION), JsonSerializer.Serialize(userClaims)).ConfigureAwait(false);
        }
        #endregion
    }

    public class CustomIdentityUserRoles
    {
        public List<string>? Roles { get; set; }
        public Dictionary<string, List<string>>? UserRoles { get; set; }

        public CustomIdentityUserRoles() 
        { 
            Roles = new List<string>();
            UserRoles = new Dictionary<string, List<string>>();
        }
    }

    public class CustomIdentityUserClaims
    {
        public Dictionary<string, List<Claim>>? UserClaims { get; set; }

        public CustomIdentityUserClaims()
        {
            UserClaims = new Dictionary<string, List<Claim>>();
        }
    }
}

