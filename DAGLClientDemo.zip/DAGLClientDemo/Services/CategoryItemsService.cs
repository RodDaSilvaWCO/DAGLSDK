﻿using DAGLClientDemo.Interfaces;
using DAGLClientDemo.Models;

namespace DAGLClientDemo.Services
{
    public class CategoryItemsService : ICategoryItemsService
    {
        private IRegisteredUserList registeredUserList = null!;
        public CategoryItemsService( IRegisteredUserList regUserList )
        {
            registeredUserList = regUserList;
        }

        private static readonly List<string> categories = new List<string>
        {
            "3DPrinterDAGLCard.png", "eBookDAGLCard.png", "MusicDAGLCard.png", "PhotographyDAGLCard.png", "VideoDAGLCard.png" 
        };

        private List<string> users
        {
            get
            {
                return registeredUserList.GetUserIdList()!;
            }
        }
        //{
        //    "Alice@Alice.com", "Bob@Bob.com", "Carol@Carol.com", "Dave@Dave.com", "Edward@Edward.com"
        //};

        private static readonly List<string> descriptions = new List<string>
        {
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit",
            "Vulputate mi sit amet mauris commodo quis imperdiet massa tincidunt",
            "Iaculis urna id volutpat lacus laoreet non curabitur",
            "Pharetra magna ac placerat vestibulum lectus mauris ultrices",
            "Dignissim sodales ut eu sem",
            "Quis auctor elit sed vulputate",
            "Sed arcu non odio euismod lacinia at",
            "Est sit amet facilisis magna etiam",
            "Vel pharetra vel turpis nunc",
            "Consequat id porta nibh venenatis cras sed felis",
            "Orci phasellus egestas tellus rutrum tellus",
            "Nibh sit amet commodo nulla",
            "Tortor at auctor urna nunc id cursus metus"
        };

        public async Task<CategoryItem[]> GetItemsAsync(string categoryFileName )
        {
            return await Task.FromResult(Enumerable.Range(1, 30).Select(index => new CategoryItem
            {
                User = users[Random.Shared.Next(0, users.Count())],
                Name = $"Item# {index}",
                ImageUrl = $"/images/{categoryFileName}",
                Description = descriptions[Random.Shared.Next(0,descriptions.Count())],
                Price = Convert.ToUInt64(Random.Shared.Next(1, 11) * 1000)
                //Date = startDate.AddDays(index),
                //TemperatureC = Random.Shared.Next(-20, 55),
                //Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            }).ToArray()) ;
        }
    }
}
