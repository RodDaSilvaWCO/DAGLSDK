﻿using Microsoft.AspNetCore.Components;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DAGLClientDemo.Models;

namespace DAGLClientDemo.Pages
{
    partial class Index : ComponentBase
    {
        public List<Image> ImageList { get; set; } = new List<Image>();

        //public string SearchText = "";

        //[Inject]
        //public IImageService ImageService { get; set; }

        protected override async Task OnInitializedAsync()
        {
            //ImageList = await ImageService.GetImages(days: 100);
            ImageList = new List<Image>();
            ImageList.Add(new Image
            {
                //Title = "Music",
                //Copyright= "All Rights Reserved",
                //Date = DateTime.Now,
                Url = "/images/MusicDAGLCard.png",
                Explanation = "Songs & Beats"
            });
            ImageList.Add(new Image
            {
                //Title = "Video",
                Url = "/images/VideoDAGLCard.png",
                Explanation = "Video & Memes"
            });
            ImageList.Add(new Image
            {
                //Title = "Books",
                Url = "/images/eBookDAGLCard.png",
                Explanation = "Books & Essays"
            });
            ImageList.Add(new Image
            {
                //Title = "Books",
                Url = "/images/3DPrinterDAGLCard.png",
                Explanation = "3D-Printing"
            });
            ImageList.Add(new Image
            {
                //Title = "Books",
                Url = "/images/PhotographyDAGLCard.png",
                Explanation = "Photography"
            });
            await Task.CompletedTask;
        }

        //private IEnumerable<Image> FilteredImages => ImageList.Where(
        //    img => img.Explanation!.ToLower().Contains(SearchText.ToLower())).ToList();
    }
}
