﻿using DAGLClientDemo.Models;
using Microsoft.AspNetCore.Components;
using DAGLClientDemo.Interfaces;
using DAGLClientDemo.Components;
using MudBlazor;
using DAGLClientDemo.Shared;

namespace DAGLClientDemo.Pages
{
    public partial class ItemsList : PageBase
    {

        [Parameter] public string? CategoryImageFileName { get; set; }
        [Inject] ICategoryItemsService categoryItemService { get; set; } = default!;
        [Inject] IDialogService DialogService { get; set; } = default!;

        private CategoryItem[]? items;

        protected override async Task OnInitializedAsync()
        {
            items = await categoryItemService.GetItemsAsync(CategoryImageFileName!);
        }

        protected override void OnInitialized()
        {
            base.OnInitialized();
            SourceImage = $"/images/{CategoryImageFileName}";
        }

        public string? SourceImage { get; set; }

        private async Task<EventCallback> Purchase(ICategoryItem item)
        {
            if (CurrentUser != null!)
            {
                var parameters = new DialogParameters { { "itemDetails", item } };
                var confirm = DialogService.Show<ConfirmPurchaseDialog>($"Asset Purchase Confirmation", parameters);
                var result = await confirm.Result;
                if (!result.Cancelled)
                {
                    //if (await DAGLService.SynchronousMemberPurchase(GetUser().NormalizedEmail, item?.User!, item!.Price!))
                    if (await DAGLService.SynchronousMemberPurchaseAsync(CurrentUser.NormalizedEmail, item?.User!, item!.Price!))
                    {
                        parameters = new DialogParameters { { "Message", "" } };
                        DialogService.Show<AlertDialog>($"Transaction successful!", parameters);
                    }
                    else
                    {
                        parameters = new DialogParameters { { "Message", "Your transaction did not go through.  Please try again." } };
                        DialogService.Show<AlertDialog>($"Transaction unsuccessful!", parameters);
                    }
                }
            }
            else
            {
                var parameters = new DialogParameters { { "Message", "You must be Logged In to purchase something." } };
                DialogService.Show<AlertDialog>($"Unauthorized", parameters);
            }
            return default(EventCallback);
        }
    }
}
